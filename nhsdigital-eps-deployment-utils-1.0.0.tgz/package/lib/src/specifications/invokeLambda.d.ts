import { LambdaClient } from "@aws-sdk/client-lambda";
export declare function invokeLambda(lambda: LambdaClient, dryRun: boolean, functionName: string, payload: unknown): Promise<string>;
