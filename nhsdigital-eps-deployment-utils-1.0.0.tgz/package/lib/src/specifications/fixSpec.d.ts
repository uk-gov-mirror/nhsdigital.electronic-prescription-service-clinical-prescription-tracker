type SpecConfig = {
    spec: any;
    apiName: string;
    version: string;
    apigeeEnvironment: string;
    isPullRequest: boolean;
    awsEnvironment: string;
    stackName: string;
    mtlsSecretName: string;
    blueGreen: boolean;
};
export declare function fixSpec({ spec, apiName, version, apigeeEnvironment, isPullRequest, awsEnvironment, stackName, mtlsSecretName, blueGreen }: SpecConfig): string;
export {};
