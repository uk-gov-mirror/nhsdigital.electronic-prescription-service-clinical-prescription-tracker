export type ApiConfig = {
    spec: any;
    apiName: string;
    version: string;
    apigeeEnvironment: string;
    isPullRequest: boolean;
    awsEnvironment: string;
    stackName: string;
    mtlsSecretName: string;
    clientCert: string;
    clientPrivateKey: string;
    proxygenPrivateKeyExportName: string;
    proxygenKid: string;
    hiddenPaths: Array<string>;
};
export declare function deployApi({ spec, apiName, version, apigeeEnvironment, isPullRequest, awsEnvironment, stackName, mtlsSecretName, clientCert, clientPrivateKey, proxygenPrivateKeyExportName, proxygenKid, hiddenPaths }: ApiConfig, blueGreen: boolean, dryRun: boolean): Promise<void>;
