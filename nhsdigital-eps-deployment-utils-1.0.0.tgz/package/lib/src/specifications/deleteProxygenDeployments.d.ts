/**
 * Deletes Proxygen PTL deployments for closed pull requests across internal-dev and internal-dev-sandbox.
 *
 * For each supported Apigee environment, this function queries existing Proxygen instances
 * for the given API and deletes those whose instance name corresponds to a closed GitHub PR
 * in the specified repository.
 *
 * @param apigeeApi - The Apigee API name whose Proxygen deployments should be cleaned up.
 * @param repoName - The GitHub repository name used to look up pull request state.
 * @param proxygenPrivateKeyName - The CloudFormation export key for the Proxygen private key secret.
 * @param proxygenKid - The key ID (kid) used when invoking the Proxygen Lambda functions.
 * @returns A promise that resolves when all eligible deployments have been processed.
 */
export declare function deleteProxygenDeployments(apigeeApi: string, repoName: string, proxygenPrivateKeyName: string, proxygenKid: string): Promise<void>;
