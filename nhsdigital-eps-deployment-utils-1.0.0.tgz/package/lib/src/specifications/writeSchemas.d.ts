import { JSONSchema } from "json-schema-to-ts";
export declare function writeSchemas(schemas: Record<string, JSONSchema>, outputDir: string): void;
