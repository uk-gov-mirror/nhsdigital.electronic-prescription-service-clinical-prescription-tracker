export declare function getConfigFromEnvVar(varName: string, defaultValue?: string | undefined): string;
export declare function getBooleanConfigFromEnvVar(varName: string, defaultValue?: string | undefined): boolean;
export declare function getNumberConfigFromEnvVar(varName: string, defaultValue?: string | undefined): number;
export declare function getCloudFormationExports(region?: string): Promise<Record<string, string>>;
export declare function getCFConfigValue(exports: Record<string, string>, exportName: string): string;
export declare function getBooleanCFConfigValue(exports: Record<string, string>, exportName: string): boolean;
export declare function calculateVersionedStackName(baseStackName: string, version: string): string;
