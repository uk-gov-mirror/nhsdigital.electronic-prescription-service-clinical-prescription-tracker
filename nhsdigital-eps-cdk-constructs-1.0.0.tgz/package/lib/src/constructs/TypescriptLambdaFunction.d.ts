import { IManagedPolicy, IRole, ManagedPolicy, Role } from "aws-cdk-lib/aws-iam";
import { Architecture, ILayerVersion, Runtime } from "aws-cdk-lib/aws-lambda";
import { NodejsFunction } from "aws-cdk-lib/aws-lambda-nodejs";
import { Construct } from "constructs";
import { IKey } from "aws-cdk-lib/aws-kms";
import { CfnDeliveryStream } from "aws-cdk-lib/aws-kinesisfirehose";
export interface TypescriptLambdaFunctionProps {
    /**
     * Name of the lambda function. The log group name is also based on this name.
     *
     */
    readonly functionName: string;
    /**
     * The base directory for resolving the package base path and entry point.
     * Should point to the monorepo root.
     */
    readonly projectBaseDir: string;
    /**
     * The relative path from projectBaseDir to the base folder where the lambda function code is located.
     *
     */
    readonly packageBasePath: string;
    /**
     * The entry point file for the Lambda function, relative to the package base path.
     *
     */
    readonly entryPoint: string;
    /**
     * A map of environment variables to set for the lambda function.
     */
    readonly environmentVariables: {
        [key: string]: string;
    };
    /**
     * Optional additional IAM policies to attach to role the lambda executes as.
     */
    readonly additionalPolicies?: Array<IManagedPolicy>;
    /**
     * The number of days to retain logs in CloudWatch Logs.
     * @default 30 days
     */
    readonly logRetentionInDays: number;
    /**
     * The log level for the lambda function.
     * @default "INFO"
     */
    readonly logLevel: string;
    /**
     * The version tag being deployed. Passed as environment variable VERSION_NUMBER to the function.
     */
    readonly version: string;
    /**
     * The commit ID being deployed. Passed as environment variable COMMIT_ID to the function.
     */
    readonly commitId: string;
    /**
     * Optional list of Lambda layers to attach to the function.
     */
    readonly layers?: Array<ILayerVersion>;
    /**
     * Optional timeout in seconds for the Lambda function.
     * @default 50 seconds
     */
    readonly timeoutInSeconds?: number;
    /**
     * Optional runtime for the Lambda function.
     * @default Runtime.NODEJS_24_X
     */
    readonly runtime?: Runtime;
    /**
     * Optional architecture for the Lambda function. Defaults to x86_64.
     * @default Architecture.X86_64
     */
    readonly architecture?: Architecture;
    /**
     * Optional KMS key for encrypting CloudWatch Logs.
     * If not provided, the value is imported from account resources export.
     */
    readonly cloudWatchLogsKmsKey?: IKey;
    /**
     * Optional IAM policy for allowing CloudWatch to use the KMS key for encrypting logs.
     * If not provided, the value is imported from account resources export.
     */
    readonly cloudwatchEncryptionKMSPolicy?: IManagedPolicy;
    /**
     * Optional firehose delivery stream for forwarding logs to Splunk.
     * If not provided, the value is imported from account resources export.
     */
    readonly splunkDeliveryStream?: CfnDeliveryStream;
    /**
     * Optional IAM role for the subscription filter that forwards logs to Splunk.
     * If not provided, the value is imported from account resources export.
     */
    readonly splunkSubscriptionFilterRole?: IRole;
    /**
     * Optional IAM policy for allowing lambdas to use Lambda Insights log groups and streams.
     * If not provided, the value is imported from account resources export.
     */
    readonly lambdaInsightsLogGroupPolicy?: IManagedPolicy;
    /**
     * Whether to create a subscription filter on the Lambda log group to forward logs to Splunk. Defaults to true.
     */
    readonly addSplunkSubscriptionFilter?: boolean;
}
/**
 * A construct that creates a TypeScript-based AWS Lambda function with all necessary AWS resources.
 *
 */
export declare class TypescriptLambdaFunction extends Construct {
    /**
     * The managed policy that allows execution of the Lambda function.
     *
     * Use this policy to grant other AWS resources permission to invoke this Lambda function.
     *
     * @example
     * ```typescript
     * // Grant API Gateway permission to invoke the Lambda
     * apiGatewayRole.addManagedPolicy(lambdaConstruct.executionPolicy);
     * ```
     */
    readonly executionPolicy: ManagedPolicy;
    /**
     * The Lambda function instance.
     *
     * Provides access to the underlying AWS Lambda function for additional configuration
     * or to reference its ARN, name, or other properties.
     *
     * @example
     * ```typescript
     * // Get the function ARN
     * const functionArn = lambdaConstruct.function.functionArn;
     *
     * // Add additional environment variables
     * lambdaConstruct.function.addEnvironment('NEW_VAR', 'value');
     * ```
     */
    readonly function: NodejsFunction;
    /**
     * The IAM role assumed by the Lambda function during execution.
     */
    readonly executionRole: Role;
    /**
     * Creates a new TypescriptLambdaFunction construct.
     *
     * This construct creates:
     * - A Lambda function with TypeScript bundling
     * - CloudWatch log group with KMS encryption
     * - Managed IAM policy for writing logs
     * - IAM role for execution with necessary permissions
     * - Subscription filter on logs so they are forwarded to splunk
     * - Managed IAM policy for invoking the Lambda function
     *
     * It also
     * - attaches the Lambda Insights layer for monitoring.
     * - adds cfnGuard suppressions for common issues.
     * - adds cdk-nag suppressions for common issues.
     *
     * @example
     * ```typescript
     * const lambdaFunction = new TypescriptLambdaFunction(this, 'MyFunction', {
     *   functionName: 'my-lambda',
     *   projectBaseDir: '/path/to/monorepo',
     *   packageBasePath: 'packages/my-lambda',
     *   entryPoint: 'src/handler.ts',
     *   environmentVariables: {
     *     TABLE_NAME: 'my-table'
     *   },
     *   logRetentionInDays: 30,
     *   logLevel: 'INFO',
     *   version: '1.0.0',
     *   commitId: 'abc123'
     * });
     * @param scope - The scope in which to define this construct
     * @param id - The scoped construct ID. Must be unique amongst siblings in the same scope
     * @param props - Configuration properties for the Lambda function
     */
    constructor(scope: Construct, id: string, props: TypescriptLambdaFunctionProps);
}
