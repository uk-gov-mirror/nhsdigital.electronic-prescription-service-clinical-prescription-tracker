import { Duration } from "aws-cdk-lib";
import { Construct } from "constructs";
import { Alarm, CreateAlarmOptions, Metric, MetricStatConfig } from "aws-cdk-lib/aws-cloudwatch";
import { ITopic } from "aws-cdk-lib/aws-sns";
/**
 * Alarm definition for SnsAlarm with defaults applied by the construct.
 */
export interface SnsAlarmDefinition extends Omit<CreateAlarmOptions, "threshold" | "evaluationPeriods"> {
    /**
     * The value against which the specified statistic is compared.
     *
     * @default 1
     */
    readonly threshold?: number;
    /**
     * The number of periods over which data is compared to the specified threshold.
     *
     * @default 1
     */
    readonly evaluationPeriods?: number;
}
/**
 * Metric stat configuration for SnsAlarm with defaults applied by the construct.
 */
export interface SnsMetricStatConfig extends Omit<MetricStatConfig, "period" | "statistic"> {
    /**
     * How many seconds to aggregate over.
     *
     * @default Duration.minutes(1)
     */
    readonly period?: Duration;
    /**
     * Aggregation function to use.
     *
     * @default "Sum"
     */
    readonly statistic?: string;
}
/**
 * Constructs a concrete CloudWatch Metric from a MetricStatConfig.
 * @see {@link import("aws-cdk-lib/aws-cloudwatch").MetricConfig} for alternate concrete metric configs.
 */
export declare const metricFromStatConfig: (metricStatConfig: MetricStatConfig) => Metric;
/**
 * Configuration for creating a CloudWatch metric alarm with SNS publication construct.
 */
export interface SnsAlarmProps {
    /** Prefix used in the generated CloudWatch alarm name. */
    readonly stackName: string;
    /** Enables alarm actions when true, disabling notifications when false. */
    readonly enableAlerts: boolean;
    /** CloudWatch metric and threshold settings for the alarm. */
    readonly alarmDefinition: SnsAlarmDefinition;
    /** Defines the metric configuration to be monitored by the alarm. */
    readonly metricStatConfig: SnsMetricStatConfig;
    /** SNS topic that receives alarm, OK, and insufficient data notifications. Common example is for Slack alerts. */
    readonly snsTopic: ITopic;
}
/**
 * Creates a single CloudWatch alarm and wires all alarm state changes to an SNS topic.
 */
export declare class SnsAlarm extends Construct {
    readonly alarm: Alarm;
    /**
     * Creates a CloudWatch alarm and publishes alarm state changes to the provided SNS topic.
     *
     * @param props Alarm configuration including metric settings, threshold settings, and notification topic.
     * @example
     * new SnsAlarm(this, 'MyApiErrorAlarm', {
     *   stackName: 'pfp-prod',
     *   enableAlerts: true,
     *   alarmDefinition: {
     *     alarmDescription: 'API errors detected',
     *     threshold: 1
     *   },
     *   metricStatConfig: {
     *     namespace: 'LambdaLogFilterMetrics',
     *     metricName: 'ErrorCount'
     *   },
     *   snsTopic: slackAlertTopic
     * })
     */
    constructor(scope: Construct, id: string, props: SnsAlarmProps);
}
