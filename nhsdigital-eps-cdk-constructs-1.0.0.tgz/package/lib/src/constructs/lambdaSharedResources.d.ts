import { Construct } from "constructs";
import { Architecture, ILayerVersion } from "aws-cdk-lib/aws-lambda";
import { IKey } from "aws-cdk-lib/aws-kms";
import { LogGroup } from "aws-cdk-lib/aws-logs";
import { IManagedPolicy, IRole, Role } from "aws-cdk-lib/aws-iam";
import { CfnDeliveryStream } from "aws-cdk-lib/aws-kinesisfirehose";
export interface SharedLambdaResourceProps {
    readonly functionName: string;
    readonly logRetentionInDays: number;
    readonly additionalPolicies: Array<IManagedPolicy>;
    readonly architecture: Architecture;
    readonly cloudWatchLogsKmsKey?: IKey;
    readonly cloudwatchEncryptionKMSPolicy?: IManagedPolicy;
    readonly splunkDeliveryStream?: CfnDeliveryStream;
    readonly splunkSubscriptionFilterRole?: IRole;
    readonly lambdaInsightsLogGroupPolicy?: IManagedPolicy;
    readonly addSplunkSubscriptionFilter?: boolean;
}
export interface SharedLambdaResources {
    readonly logGroup: LogGroup;
    readonly role: Role;
    readonly insightsLayer: ILayerVersion;
}
export declare const createSharedLambdaResources: (scope: Construct, props: SharedLambdaResourceProps) => SharedLambdaResources;
