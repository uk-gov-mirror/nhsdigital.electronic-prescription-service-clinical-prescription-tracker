import { ManagedPolicy } from "aws-cdk-lib/aws-iam";
import { StringParameter } from "aws-cdk-lib/aws-ssm";
import { Construct } from "constructs";
/**
 * Definition for a single SSM String parameter and its output export metadata.
 *
 * @property id Unique identifier used for construct and output logical IDs.
 * @property nameSuffix Suffix appended to stackName to create the parameter name.
 * The final SSM parameter name is `${stackName}-${nameSuffix}`.
 * @property description Description stored with the SSM parameter.
 * @property value Value stored in the SSM parameter.
 * @property outputExportSuffix Optional export suffix for the output containing
 * the parameter name. Defaults to `nameSuffix`.
 * @property outputDescription Optional output description. Defaults to
 * `description`.
 */
export interface SsmParameterDefinition {
    /**
     * Unique identifier used for construct and output logical IDs.
     */
    readonly id: string;
    /**
     * Suffix appended to stackName to create the parameter name.
     * The final SSM parameter name is `${stackName}-${nameSuffix}`.
     */
    readonly nameSuffix: string;
    /**
     * Description stored with the SSM parameter.
     */
    readonly description: string;
    /**
     * Value stored in the SSM parameter.
     */
    readonly value: string;
}
/**
 * Properties used to configure {@link SsmParametersConstruct}.
 *
 * @property namePrefix Prefix used in SSM parameter names and CloudFormation
 * export names.
 * @property parameters List of SSM parameters to create.
 * @property readPolicyDescription Description for the managed policy that grants
 * read access. Defaults to "Allows reading SSM parameters".
 */
export interface SsmParametersConstructProps {
    /**
     * Prefix used in SSM parameter names and CloudFormation export names.
     */
    readonly namePrefix: string;
    /**
     * List of SSM parameters to create.
     */
    readonly parameters: Array<SsmParameterDefinition>;
    /**
     * Description for the managed policy that grants read access.
     * @default "Allows reading SSM parameters"
     */
    readonly readPolicyDescription?: string;
}
/**
 * Creates a bundle of SSM String parameters, a managed policy to read them,
 * and CloudFormation outputs to export parameter names and policy ARN.
 */
export declare class SsmParametersConstruct extends Construct {
    readonly parameters: Record<string, StringParameter>;
    readonly readParametersPolicy: ManagedPolicy;
    /**
     * Creates SSM String parameters, a managed read policy, and CloudFormation outputs.
     *
     * @param scope CDK construct scope.
     * @param id Unique construct identifier.
     * @param props Configuration for parameter names, values, and exported outputs.
     * @throws {Error} Throws when no parameter definitions are provided.
     * @throws {Error} Throws when duplicate parameter IDs or parameter names are detected.
     */
    constructor(scope: Construct, id: string, props: SsmParametersConstructProps);
}
