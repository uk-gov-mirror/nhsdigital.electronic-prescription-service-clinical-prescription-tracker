import { AccessLogFormat } from "aws-cdk-lib/aws-apigateway";
/**
 * @returns Access-log formatter configured with the package standard schema.
 */
export declare const accessLogFormat: () => AccessLogFormat;
