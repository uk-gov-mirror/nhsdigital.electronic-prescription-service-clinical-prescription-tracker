/** VTL response template that unwraps successful workflow output and forwards status and headers. */
export declare const stateMachine200ResponseTemplate = "#set($payload = $util.parseJson($input.path('$.output')))\n#set($context.responseOverride.status = $payload.Payload.statusCode)\n#set($allHeaders = $payload.Payload.headers)\n#foreach($headerName in $allHeaders.keySet())\n    #set($context.responseOverride.header[$headerName] = $allHeaders.get($headerName))\n#end\n$payload.Payload.body";
/**
 * @returns VTL response template that maps workflow failures to FHIR OperationOutcome payloads.
 */
export declare const stateMachineErrorResponseTemplate: (status: string) => string;
