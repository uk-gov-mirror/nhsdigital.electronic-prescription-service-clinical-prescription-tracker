import { DescribeChangeSetCommandOutput } from "@aws-sdk/client-cloudformation";
export type ChangeRequiringAttention = {
    logicalId: string;
    physicalId: string;
    resourceType: string;
    policyAction: string;
    action: string;
    replacement: string;
};
export type AllowedDestructiveChange = {
    LogicalResourceId: string;
    PhysicalResourceId: string;
    ResourceType: string;
    PolicyAction?: string | null;
    Action?: string | null;
    Replacement?: string | null;
    ExpiryDate: string | Date;
    StackName: string;
    AllowedReason: string;
};
/**
 * Extracts the subset of CloudFormation changes that either require replacement or remove resources.
 *
 * @param changeSet - Raw change-set details returned from `DescribeChangeSet`.
 * @returns Array of changes that need operator attention.
 */
export declare function checkDestructiveChanges(changeSet: DescribeChangeSetCommandOutput | undefined | null): Array<ChangeRequiringAttention>;
/**
 * Describes a CloudFormation change set, applies waiver logic, and throws if destructive changes remain.
 *
 * @param changeSetName - Name or ARN of the change set.
 * @param stackName - Name or ARN of the stack that owns the change set.
 * @param region - AWS region where the stack resides.
 * @param allowedChanges - Optional waivers that temporarily allow specific destructive changes.
 */
export declare function checkDestructiveChangeSet(changeSetName: string, stackName: string, region: string, allowedChanges?: Array<AllowedDestructiveChange>): Promise<void>;
