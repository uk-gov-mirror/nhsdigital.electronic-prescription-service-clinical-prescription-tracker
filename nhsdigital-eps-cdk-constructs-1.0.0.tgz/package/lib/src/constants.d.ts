/** Default prefix used for CDK config environment variables. */
export declare const CDK_ENV_PREFIX = "CDK_CONFIG_";
/** Imported cross-stack account resource values used by constructs in this package. */
export declare const ACCOUNT_RESOURCES: {
    CloudwatchEncryptionKMSPolicyArn: string;
    CloudwatchLogsKmsKeyArn: string;
    EpsDomainName: string;
    EpsZoneId: string;
    LambdaAccessSecretsPolicy: string;
    LambdaDecryptSecretsKMSPolicy: string;
    SpinePrivateKeyARN: string;
    SpinePublicCertificateARN: string;
    SpineASIDARN: string;
    SpinePartyKeyARN: string;
    SpineCAChainARN: string;
    TrustStoreBucket: string;
    TrustStoreBucketKMSKey: string;
    TrustStoreDeploymentBucket: string;
};
/** Imported shared Lambda resource values used by Lambda and API Gateway constructs. */
export declare const LAMBDA_RESOURCES: {
    LambdaInsightsLogGroupPolicy: string;
    SplunkDeliveryStream: string;
    SplunkSubscriptionFilterRole: string;
};
/** Shared cfn-guard rule identifiers used for metadata suppressions. */
export declare const CFN_GUARD_RULES: {
    readonly LogGroupRetentionPeriodCheck: "CW_LOGGROUP_RETENTION_PERIOD_CHECK";
};
