import { CfnResource } from "aws-cdk-lib";
import { NagRuleCompliance } from "cdk-nag";
/**
 * API Gateway logs are configured in JSON format.
 * @param node the CfnResource to check
 */
declare const _default: (node: CfnResource) => NagRuleCompliance;
export default _default;
