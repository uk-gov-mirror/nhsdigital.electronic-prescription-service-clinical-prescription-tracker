import { CfnResource } from "aws-cdk-lib";
import { NagRuleCompliance } from "cdk-nag";
/**
 * APIs gateway have mutual TLS enabled unless this is a pull request
 * @param node the CfnResource to check
 */
declare const _default: (node: CfnResource) => NagRuleCompliance;
export default _default;
